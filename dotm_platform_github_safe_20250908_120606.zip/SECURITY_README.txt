DOTM Platform - GitHub Safe Archive
Created: 2025-09-08 12:06:07

🔒 SECURITY NOTICE:
This archive has been sanitized for GitHub upload and contains NO:
- Private user data or personal information
- API keys, tokens, or credentials  
- Database connection strings
- Firebase configuration files
- Payment processing sensitive data
- User migration scripts or data exports

📁 SAFE CONTENTS INCLUDED:

🔌 MCP Server Core:
- mcp_server.py - Model Context Protocol server (sanitized)
- mcp_server_rules.md - Server operation rules
- test_mcp.py - Test suite

📚 Documentation:
- docs/ - Complete documentation suite
- README_MCP.md - MCP server guide  
- GITHUB_UPLOAD_GUIDE.md - Upload instructions

🎨 Frontend Assets:
- templates/ - HTML templates
- static/ - CSS, JavaScript, images
- No user-generated content

🗄️ Database Schema:
- SQL table creation files
- No actual user data or records
- Schema definitions only

⛓️ Smart Contracts:
- contracts/DOTMToken.sol - ERC20 token contract
- artifacts/ - Compiled contract artifacts  
- scripts/ - Deployment utilities

📦 Configuration:
- requirements.txt - Python dependencies
- package.json - Node.js dependencies
- Safe configuration files only

🚀 Live Demo URLs (Public):
- MCP Server: https://get-dot-esim.replit.app/mcp
- API Endpoint: https://get-dot-esim.replit.app/mcp/api
- Alternative: https://mcp.dotmobile.app

⚠️ EXCLUDED FOR SECURITY:
- main.py (contains sensitive integrations)
- All *_helper.py files (contain API keys)
- User data migration scripts
- Debug scripts with real data
- Environment configuration files
- Any files containing credentials

This archive is safe for public GitHub repositories and contains
only public-facing code, documentation, and schema definitions.

For the complete private codebase, use the internal development
environment on Replit.
