DOTM Platform Archive
Created: 2025-09-08 08:01:07

This archive contains the complete DOTM Platform codebase including:

📁 Core Application:
- main.py - Main Flask application
- mcp_server.py - Model Context Protocol server
- oxio_service.py - OXIO API integration
- stripe_products.py - Payment processing

📁 Documentation:
- docs/ - Complete documentation
- README_MCP.md - MCP server documentation
- GITHUB_UPLOAD_GUIDE.md - GitHub publishing guide

📁 Frontend:
- templates/ - HTML templates
- static/ - CSS, JavaScript, and assets

📁 Database:
- SQL files for table creation
- Migration and sync scripts

📁 Smart Contracts:
- contracts/ - Solidity contracts
- artifacts/ - Compiled contract artifacts

📁 Configuration:
- requirements.txt - Python dependencies
- package.json - Node.js dependencies
- hardhat.config.js - Blockchain development config

🚀 Live Platform URLs:
- Main Platform: https://get-dot-esim.replit.app
- MCP Server: https://get-dot-esim.replit.app/mcp
- Alternative MCP: https://mcp.dotmobile.app

For deployment instructions, see GITHUB_UPLOAD_GUIDE.md
